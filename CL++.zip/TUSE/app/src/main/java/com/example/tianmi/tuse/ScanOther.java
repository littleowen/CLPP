package com.example.tianmi.tuse;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ScanOther extends AppCompatActivity {

    String total_scanned;
    boolean triedtosend;
    boolean send_success;
    String card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_other);
        total_scanned="";
        triedtosend=false;
        send_success=false;
        Scan();
    }

    public void Scan(View view)
    {
        Scan();
    }
    public void Scan()
    {
        IntentIntegrator.initiateScan(ScanOther.this);
        //IntentIntegrator.initiateScan(scanCode.this, "CODE_128");//QR_CODE
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        try {
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
            if (scanResult != null) {
                // handle scan result
                total_scanned = intent.getStringExtra("SCAN_RESULT");
            }
        }
        catch(Exception e) {
            total_scanned ="";
            Toast toast
                    = Toast.makeText(this.getApplicationContext(), "SCAN: "+this.getString(R.string.no_code, MainActivity.DURATION), MainActivity.DURATION);
            toast.show();
            return;
        }
    }

    public void Send(View view){
        new scanned(ScanOther.this, getApplicationContext()).execute();
        //wait till finish
        for(int iter=0; iter<15; iter++){//at most exec_times + 15 seconds
            try{ Thread.sleep(1000); }catch(InterruptedException e){
                String temp=this.getString(R.string.overtime);
                Toast toast = Toast.makeText(this.getApplicationContext(), temp, MainActivity.DURATION);
                toast.show();
            }
            if(triedtosend)break;
        }
        triedtosend=false;//set back
        if(send_success){
            /*retrieve new card*/
            SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            //Retrieve the values
            Set<String> set_old = sharedpreferences.getStringSet(MainActivity.Othercard, null);
            //Set the values
            Set<String> set_new = new HashSet<String>();
            if(set_old!=null)
                set_new.addAll(set_old);
            set_new.add(card);
            editor.putStringSet(MainActivity.Othercard, set_new);
            String tmp=sharedpreferences.getString(MainActivity.Filesystem, "");
            editor.putString(MainActivity.Filesystem, tmp + "Categories/New Contact/"+total_scanned+"\n");
            editor.commit();
        }
        total_scanned="";//set back
    }
}
