package com.example.tianmi.tuse;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.provider.ContactsContract;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.client.android.Intents;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Index extends AppCompatActivity {

    private ListView mDrawerList;
    private ArrayAdapter<String> mAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private String mActivityTitle;
    //for the sake of updates
    private static String owncard;
    private static Set<String> othercard;
    protected static void set_owncard(String temp) { owncard=temp;    }
    protected static void set_othercard(Set<String> temp){othercard.addAll(temp);    }
    boolean triedupdate;
    /**TODO not todo but from OWEN **/
    private TextView Subject;
    private ListView listViewEntry;
    private Button selectButton;
    private Button importButton;
    private Context ctx;
    private String category;
    private String currentSystem;
    private List<Entry> selectedEntries = new ArrayList<Entry>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //TextView greet;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        mDrawerList = (ListView)findViewById(R.id.navList);
        addDrawerItems();
        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        setupDrawer();
/*
//updating using Retrieve_Update
        SharedPreferences tmp=getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = tmp.edit();
        triedupdate=false;
        //get cards if certain cards don't exist yet
        //using Retrieve_update to download existing own and other cards
        new Retrieve_Update(Index.this, tmp.getString(MainActivity.Name, " "));
        for(int iter=0; iter<15; iter++){//at most exec_times + 15 seconds
            try{ Thread.sleep(1000); }catch(InterruptedException e){
                String temp=this.getString(R.string.overtime);
                Toast toast = Toast.makeText(this.getApplicationContext(), temp, MainActivity.DURATION);
                toast.show();
            }
            if(triedupdate)break;
        }
        //now that owncard and othercard are updated, write to preference
        //Set the values
        if(othercard!=null)
            editor.putStringSet(MainActivity.Othercard, othercard);
        if(!owncard.equals(""))
            editor.putString(MainActivity.Owncard, owncard);
        editor.commit();
*/
        OWEN_onCreate();
    }

    private void addDrawerItems() {
        String[] Array = { this.getString(R.string.title_activity_scan_other),
                this.getString(R.string.title_activity_display_mine)};
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Array);
        mDrawerList.setAdapter(mAdapter);
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        menu_0();
                        break;
                    case 1:
                        menu_1();
                        break;
                    default:
                        break;
                }
            }
        });
    }
    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle(R.string.advanced_option);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void logout(){
        //first go to login page then finish
        SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.clear();
        editor.commit();
        Intent in = new Intent(Index.this,Login.class);
        startActivity(in);
        finish();
    }
    private void menu_0() {
        Intent intent = new Intent(this, ScanOther.class);
        startActivity(intent);
    }
    private void menu_1() {
        Intent intent = new Intent(this, DisplayMine.class);
        startActivity(intent);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, R.id.menu_action1, Menu.NONE, R.string.button_logout);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.menu_action1:
                logout();
                return true;
            case R.id.action_settings://noinspection SimplifiableIfStatement
                return true;
            default:
                // Activate the navigation drawer toggle
                if (mDrawerToggle.onOptionsItemSelected(item)) {
                    return true;
                }
                return super.onOptionsItemSelected(item);
        }
    }


    /**TODO actually not todo but from OWEN**/
    private void OWEN_onCreate() {

        Subject = (TextView)findViewById(R.id.Subject);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            category = extras.getString("category");
            Subject.setText(category);

        } else {
            category = "Categories";
            Subject.setText(category);
			String testSystem = "Categories/College/Pele\nCategories/College/Diego Maradona\n" +
					"Categories/Company/Donald Trump\nCategories/Company/Franz Beckenbauer\n" +
					"Categories/Company/Students/Michel Platini\n" +
					"Categories/Company/Students/Ronaldo De Lim\n";

            SharedPreferences sharedPreferences=getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);

            if(sharedPreferences.getString(MainActivity.Filesystem, "").length()<6)
                savePreferences(MainActivity.Filesystem, testSystem);
        }

        currentSystem = loadSavedPreferences(MainActivity.Filesystem, "");
        ctx = this;
        final List<Entry> entryList = ListfromSystem(currentSystem, category, "[\n]", "[/]");

        listViewEntry = (ListView) findViewById(R.id.Entry_list);
        listViewEntry.setAdapter(new CategoryListAdapter(ctx, R.layout.category_row_item, entryList));




        // Click event for single list row
        listViewEntry.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Entry o = (Entry) parent.getItemAtPosition(position);
                if (o.getMode().toString().equals("category")) {
                    Intent in = new Intent(Index.this, Index.class);
                    in.putExtra("category", o.getName().toString());
                    startActivity(in);
                } else {
                    Toast.makeText(Index.this, o.getName().toString(), Toast.LENGTH_SHORT).show();
                    Intent in = new Intent(Index.this, Display.class);
                    in.putExtra("name", o.getName().toString());
                    startActivity(in);
                }

            }


        });

        selectButton = (Button) findViewById(R.id.Select);
        importButton = (Button) findViewById(R.id.Import);

        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < listViewEntry.getChildCount(); i++) {

                    CheckBox cb = (CheckBox) listViewEntry.getChildAt(i).findViewById(R.id.checkbox);
                    if (entryList.get(i).getMode().equals("category")){
                        break;
                    }
                    cb.setVisibility(View.VISIBLE);
                    cb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            CheckBox cb = (CheckBox) v;
                            boolean checked = cb.isChecked();
                            Entry o = (Entry) cb.getTag();
                            if (checked) {
                                selectedEntries.add(o);
                            }
                        }
                    });
                }

                selectButton.setVisibility(View.GONE);
                importButton.setVisibility(View.VISIBLE);
            }
        });

        importButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedEntries.isEmpty()){
                    for (int i = 0; i < selectedEntries.size(); i++) {
                        String Name = selectedEntries.get(i).getName();
                        String MobileNumber = "123456";
                        String HomeNumber = "1111";
                        String WorkNumber = "2222";
                        String email = "email@nomail.com";
                        String company = "bad";
                        String jobTitle = "abcd";
                        importContacts(Name, MobileNumber, HomeNumber, WorkNumber, email, company, jobTitle);
                    }

                }
                for (int i = 0; i < listViewEntry.getChildCount(); i++) {
                    listViewEntry.getChildAt(i).findViewById(R.id.checkbox).setVisibility(View.GONE);
                }



                importButton.setVisibility(View.GONE);
                selectButton.setVisibility(View.VISIBLE);
            }
        });
    }

    //modified
    private void savePreferences(String key, String value) {
        SharedPreferences sharedpreferences;
        sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();

        editor.putString(key, value);

        editor.commit();

    }

    //modified
    private String loadSavedPreferences(String key, String defval) {

        SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(key, defval);

    }

    //modified
    public List<Entry> ListfromSystem(String System, String Cate, String Rdelim, String Cdelim){
        List<Entry> entryList = new ArrayList<Entry>();
        String[] entries = System.split(Rdelim);
        String[] levels;
        String existing="";

        for (int i = 0; i < entries.length; i++) {
            levels = entries[i].split(Cdelim);
            for (int j = 0; j < levels.length; j++) {
                String mode = "category";
                String image = "folder";
                if(levels[j].equals(Cate)){
                    if (j == levels.length-2) {
                        mode = "contact";
                        image = "user";
                    } else if(existing.contains(levels[j+1])) {
                        break;
                    }
                    if (mode.equals("contact")) {
                        // here send request for more info
                        entryList.add(new Entry(levels[j+1], mode, image, "Empty", ""));
                    } else {
                        existing = existing.concat(levels[j+1]);
                        entryList.add(new Entry(levels[j + 1], mode, image, "Empty", ""));
                    }

                    break;
                }
            }
        }


        return entryList;
    }

    public void importContacts(String name, String mobile, String home, String work, String email, String Company, String job){
        String DisplayName = name;
        String MobileNumber = mobile;
        String HomeNumber = home;
        String WorkNumber = work;
        String emailID = email;
        String company = Company;
        String jobTitle = job;

        ArrayList <ContentProviderOperation> ops = new ArrayList < > ();

        ops.add(ContentProviderOperation.newInsert(
                ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build());

        //------------------------------------------------------ Names
        if (DisplayName != null) {
            ops.add(ContentProviderOperation.newInsert(
                    ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                            DisplayName).build());
        }

        //------------------------------------------------------ Mobile Number
        if (MobileNumber != null) {
            ops.add(ContentProviderOperation.
                    newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, MobileNumber)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build());
        }

        //------------------------------------------------------ Home Numbers
        if (HomeNumber != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, HomeNumber)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_HOME)
                    .build());
        }

        //------------------------------------------------------ Work Numbers
        if (WorkNumber != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, WorkNumber)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
                    .build());
        }

        //------------------------------------------------------ Email
        if (emailID != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Email.DATA, emailID)
                    .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                    .build());
        }

        //------------------------------------------------------ Organization
        if (!company.equals("") && !jobTitle.equals("")) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Organization.COMPANY, company)
                    .withValue(ContactsContract.CommonDataKinds.Organization.TYPE, ContactsContract.CommonDataKinds.Organization.TYPE_WORK)
                    .withValue(ContactsContract.CommonDataKinds.Organization.TITLE, jobTitle)
                    .withValue(ContactsContract.CommonDataKinds.Organization.TYPE, ContactsContract.CommonDataKinds.Organization.TYPE_WORK)
                    .build());
        }

        // Asking the Contact provider to create a new contact
        try {
            getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(Index.this, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}