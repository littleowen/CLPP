package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.zxing.client.android.Intents;


public class preIndex extends Activity {

    EditText editText1;
    EditText editText2;
    EditText editText3;
    EditText editText4;
    EditText editText5;
    EditText editText6;
    EditText editText7;
    EditText editText8;
    EditText editText9;

    String family_name;
    String given_name;
    String middle_name;
    String position;
    String website;
    String email;
    String phone;
    String fax;
    String title;
    String username;

    boolean finish_transfer;
    boolean finish_success;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_index);
        editText1=(EditText)findViewById(R.id.editText1);
        editText2=(EditText)findViewById(R.id.editText2);
        editText3=(EditText)findViewById(R.id.editText3);
        editText4=(EditText)findViewById(R.id.editText4);
        editText5=(EditText)findViewById(R.id.editText5);
        editText6=(EditText)findViewById(R.id.editText6);
        editText7=(EditText)findViewById(R.id.editText7);
        editText8=(EditText)findViewById(R.id.editText8);
        editText9=(EditText)findViewById(R.id.editText9);
        finish_success=false;
        finish_transfer=false;

        SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        username=sharedpreferences.getString(MainActivity.Name, "");
    }

    public void goOn (View v){

        family_name=editText1.getText().toString();
        given_name=editText2.getText().toString();
        middle_name=editText3.getText().toString();
        position=editText4.getText().toString();
        website=editText5.getText().toString();
        email=editText6.getText().toString();
        phone=editText7.getText().toString();
        fax=editText8.getText().toString();
        title=editText9.getText().toString();

        new sendInfo(preIndex.this, getApplicationContext()).execute();
        //wait till finish
        for(int iter=0; iter<15; iter++){//at most exec_times + 15 seconds
            try{ Thread.sleep(1000); }catch(InterruptedException e){
                String temp=this.getString(R.string.overtime);
                Toast toast = Toast.makeText(this.getApplicationContext(), temp, MainActivity.DURATION);
                toast.show();
            }
            if(finish_transfer)break;
        }
        finish_transfer=false;
        if(finish_success) {
            //go to index
            Intent in = new Intent(preIndex.this, Index.class);
            startActivity(in);
            finish();

        }

    }

}
