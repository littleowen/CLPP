package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends Activity {

    Intent in;

    /**shared preferences**/
    public static final String MyPREFERENCES = "MyPrefs";
    public static final String Name = "nameKey";
    public static final String Status = "statusKey";
    public static final String Filesystem ="FilesystemKey";
    public static final String Owncard="OwncardKey";
    public static final String Othercard="OthercardKey";

    static SharedPreferences sharedpreferences;

    public static final String Domain="https://fuse-eu.com/hackathon/";
    public static final int QRsize=500;
    public static final int DURATION = Toast.LENGTH_SHORT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get shared preferences
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        boolean temp= sharedpreferences.getBoolean(Status, false);//if not set, then false

        //async();

        if(temp)
            in = new Intent(MainActivity.this, Index.class);
        else in = new Intent(MainActivity.this, Login.class);
        startActivity(in);
        finish();
    }

    protected void async(){
        new Retrieve_Update(MainActivity.this, sharedpreferences.getString(Name, ""),
                sharedpreferences.getString(Filesystem, ""), sharedpreferences.getBoolean(Status, false)).execute();
    }
    protected void set_stuff(String temp1, Set<String> temp2){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(Owncard, temp1);
        editor.putStringSet(Othercard, temp2);
        editor.commit();
    }
}