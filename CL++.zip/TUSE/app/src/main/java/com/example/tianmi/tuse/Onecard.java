package com.example.tianmi.tuse;

/**
 * Created by tianmi on 17.10.15.
 */
public class Onecard {

    String family_name;
    String given_name;
    String middle_name;
    String position;
    String website;
    String email;
    String phone;
    String fax;
    String title;
    String username;

    String static_pic;//dir only
    String dynamic_pic;//dir only

//setters
    public void set_family_name(String temp){
        family_name=temp;
    }
    public void set_given_name(String temp){
        given_name=temp;
    }
    public void set_middle_name(String temp){
        middle_name=temp;
    }
    public void set_position(String temp){
        position=temp;
    }
    public void set_website(String temp){
        website=temp;
    }
    public void set_email(String temp){
        email=temp;
    }
    public void set_phone(String temp){
        phone=temp;
    }
    public void set_fax(String temp){
        fax=temp;
    }
    public void set_title(String temp){
        title=temp;
    }
    public void set_username(String temp){
        username=temp;
    }

    public void set_static_pic(String temp){
        static_pic=temp;
    }
    public void set_dynamic_pic(String temp){
        dynamic_pic=temp;
    }

    //getters
    public String get_family_name(){
        return family_name;
    }
    public String get_given_name(){
        return given_name;
    }
    public String get_middle_name(){
        return middle_name;
    }
    public String get_position(){
        return position;
    }
    public String get_website(){
        return website;
    }
    public String get_email(){
        return email;
    }
    public String get_phone(){
        return phone;
    }
    public String get_fax(){
        return fax;
    }
    public String get_title(){
        return title;
    }
    public String get_username(){
        return username;
    }

    public String get_static_pic(){
        return static_pic;
    }
    public String get_dynamic_pic(){
        return dynamic_pic;
    }

    //en/decode
    public Onecard (String temp){
        int index;
        String [] all;
        all= new String[12];
        for(int i=0;i<12;i++)
        {
            index=temp.indexOf(" ");
            all[i]=temp.substring(0, index-1);
            temp=temp.substring(index+1);
        }
        this.family_name=all[0];
        this.given_name=all[1];
        this.middle_name=all[2];
        this.position=all[3];
        this.website=all[4];
        this.email=all[5];
        this.phone=all[6];
        this.fax=all[7];
        this.title=all[8];
        this.username=all[9];
        this.static_pic=all[10];
        this.dynamic_pic=all[11];

    }
    public String decode () {
        return family_name+" "+given_name+" "+middle_name+" "+position+" "
                +website+" "+email+" "+phone+" "+fax+" "+title+" "
                +username+" "+static_pic+" "+dynamic_pic+" ";
    }


}
