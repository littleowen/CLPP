package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity {

    private EditText usernameField,passwordField;
    private String username, password;
    Intent in;
    SharedPreferences sharedpreferences;
    String fs;

    private boolean loggedin;
    private boolean triedtologin;
    public void set_loggedin(boolean temp){loggedin=temp;};
    public void set_triedtologin(boolean temp){triedtologin=temp;};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loggedin=false;
        triedtologin=false;

        //get shared preferences
        //if not, visualize
        usernameField = (EditText)findViewById(R.id.editText1);
        passwordField = (EditText)findViewById(R.id.editText2);
    }

    public void signUp(View view){
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();

        new SignupActivity(Login.this, getApplicationContext()).execute(username, password);
        //wait till finish
        for(int iter=0; iter<15; iter++){//at most exec_times + 15 seconds
            try{ Thread.sleep(1000); }catch(InterruptedException e){
                String temp=this.getString(R.string.overtime);
                Toast toast = Toast.makeText(this.getApplicationContext(), temp, MainActivity.DURATION);
                toast.show();
            }
            if(triedtologin)break;
        }
        triedtologin=false;//set back for statics
        if(loggedin) {//after signing up successfully
            sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            //in case there is a previously logged in user
            editor.clear();
            editor.commit();
            //status true and username
            editor.putString(MainActivity.Name, username);
            editor.putBoolean(MainActivity.Status, true);
            editor.putString(MainActivity.Filesystem, "\n");
            editor.commit();

            /*TODO check if information really filled out through last entry on sql*/

            //go to Index but also delete self
            in = new Intent(Login.this, preIndex.class);
            startActivity(in);
            finish();
        }
    }

    public void loginPost(View view){
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();
        usernameField.setText("");
        passwordField.setText("");

        new SigninActivity(Login.this, getApplicationContext()).execute(username, password);
        //wait till finish
        for(int iter=0; iter<15; iter++){//at most exec_times + 15 seconds
            try{ Thread.sleep(1000); }catch(InterruptedException e){
                String temp=this.getString(R.string.overtime);
                Toast toast = Toast.makeText(this.getApplicationContext(), temp, MainActivity.DURATION);
                toast.show();
            }
            if(triedtologin)break;
        }
        triedtologin=false;//set back for statics

        if(loggedin){//after signing in successfully
            //if(fs.charAt(fs.length()-2)=='\n') fs=fs.substring(0, fs.length()-1);
            sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            if(!sharedpreferences.getString(MainActivity.Name, "").equals("")) {
            //if previously another user
                editor.clear();
                editor.commit();
            }
            editor.putString(MainActivity.Name, username);
            editor.putBoolean(MainActivity.Status, true);
            editor.putString(MainActivity.Filesystem, fs);
            editor.commit();

            //go to Index but also delete self
            in = new Intent(Login.this, Index.class);
            startActivity(in);
            finish();
        }
    }
}