package com.example.tianmi.tuse;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class CategoryListAdapter extends ArrayAdapter<Entry> {
	private int				resource;
	private LayoutInflater	inflater;
	private Context 		context;
	public CategoryListAdapter(Context ctx, int resourceId, List<Entry> objects) {
		super( ctx, resourceId, objects );
		resource = resourceId;
		inflater = LayoutInflater.from( ctx );
		context=ctx;
	}
	@Override
	public View getView ( int position, View convertView, ViewGroup parent ) {
		convertView = ( RelativeLayout ) inflater.inflate( resource, null );

		Entry Contact = getItem(position);
			TextView categoryName = (TextView) convertView.findViewById(R.id.categoryName);
			categoryName.setText(Contact.getName());


			ImageView categoryImage = (ImageView) convertView.findViewById(R.id.categoryImage);
			String uri = "drawable/" + Contact.getImage();
			int imageResource = context.getResources().getIdentifier(uri, null, context.getPackageName());
			Drawable image = context.getResources().getDrawable(imageResource);
			categoryImage.setImageDrawable(image);
		CheckBox cb = (CheckBox) convertView.findViewById(R.id.checkbox);
		cb.setTag(Contact);

		return convertView;
	}
}

