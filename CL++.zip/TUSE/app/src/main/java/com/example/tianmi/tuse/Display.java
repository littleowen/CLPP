package com.example.tianmi.tuse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Movie;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Picasso;

import java.io.IOException;


public class Display extends AppCompatActivity {

    private SharedPreferences sharedpreferences;
    private Onecard card;
    private ImageView image_View;


    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        //generate code image
        image_View = (ImageView) findViewById(R.id.image_view);

        Bundle extras= getIntent().getExtras();
        if (extras != null) {
            name = extras.getString("name");
        }
/*
        //get data to be carded
        String str=sharedpreferences.getString(MainActivity.Owncard, " ");
        if(!str.equals(" "))
            card=new Onecard(sharedpreferences.getString(MainActivity.Owncard, " "));

        //generate card
        if(!str.equals(" "))*/
            generate_card();
    }

    private void generate_card(){
/*
        //extract card
        String family_name=card.get_family_name();
        String given_name=card.get_given_name();
        String middle_name=card.get_middle_name();
        String position=card.get_position();
        String website=card.get_website();
        String email=card.get_email();
        String phone=card.get_phone();
        String fax=card.get_fax();
        String title=card.get_title();
        String username=card.get_username();
        String static_pic=card.get_static_pic();
        String dynamic_pic=card.get_dynamic_pic();
*/
        //shown to image_View
        if(name.equals("Pele")) Picasso.with(getApplicationContext())
                .load(R.drawable.pcard).into(image_View);
        else if(name.equals("Diego Maradona") ) Picasso.with(getApplicationContext())
                .load(R.drawable.mcard).into(image_View);
        else if(name.equals("Franz Beckenbauer")) Picasso.with(getApplicationContext())
                .load(R.drawable.fcard).into(image_View);
        else if(name.equals("Donald Trump")) Ion.with(image_View)
                .load("http://i.imgur.com/z8AOXVH.gif");
        else if (name.charAt(0) == 'f') Ion.with(image_View)
                .load("http://25.media.tumblr.com/tumblr_m8i6rmeQDH1r49l3lo1_500.gif");
        else Ion.with(image_View)
                .load("http://changeorder.typepad.com/.a/6a00e54fcb6859883401a73da8df00970d-pi");


    }
}