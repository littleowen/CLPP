package com.example.tianmi.tuse;
public class Entry {
	public Entry(String name, String mode, String image, String nation, String color) {
		super();
		this.name = name;
		this.image = image;
		this.mode = mode;
		this.nation = nation;
		this.color = color;
	}
	private String name;
	private String color;
	private String image;
	private String mode;
	private String nation;

	public String getName() {
		return name;
	}
	public void setName(String nameText) {
		name = nameText;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String image) {
		this.image = mode;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}

}
