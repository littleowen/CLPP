package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by tianmi on 17.10.15.
 */
public class sendInfo  extends AsyncTask<String,Void,String> {
    private Context context;
    private preIndex instance;

    public sendInfo (Activity act, Context context) {
        instance=(preIndex)act;
        this.context=context;
    }

    protected void onPreExecute() {

    }

    @Override
    protected String doInBackground(String... arg0) {

        String family_name=instance.family_name;
        String given_name=instance.given_name;
        String middle_name=instance.middle_name;
        String position=instance.position;
        String website=instance.website;
        String email=instance.email;
        String phone=instance.phone;
        String fax=instance.fax;
        String title=instance.title;
        String username=instance.username;

        //post method
        try {

            String link = MainActivity.Domain+"fillinfo_tuse.php";
            String data = URLEncoder.encode("family_name", "UTF-8") + "=" + URLEncoder.encode(family_name, "UTF-8");
            data += "&" + URLEncoder.encode("middle_name", "UTF-8") + "=" + URLEncoder.encode(middle_name, "UTF-8");
            data += "&" + URLEncoder.encode("position", "UTF-8") + "=" + URLEncoder.encode(position, "UTF-8");
            data += "&" + URLEncoder.encode("website", "UTF-8") + "=" + URLEncoder.encode(website, "UTF-8");
            data += "&" + URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
            data += "&" + URLEncoder.encode("phone", "UTF-8") + "=" + URLEncoder.encode(phone, "UTF-8");
            data += "&" + URLEncoder.encode("fax", "UTF-8") + "=" + URLEncoder.encode(fax, "UTF-8");
            data += "&" + URLEncoder.encode("title", "UTF-8") + "=" + URLEncoder.encode(title, "UTF-8");
            data += "&" + URLEncoder.encode("given_name", "UTF-8") + "=" + URLEncoder.encode(given_name, "UTF-8");
            data += "&" + URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");

            URL url = new URL(link);
            HttpsURLConnection conn =(HttpsURLConnection) url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            String result=sb.toString();
            if(result.toLowerCase().contains("successful"))
            {
                instance.finish_transfer=true;
                instance.finish_success=true;
            }
            instance.finish_transfer=true;
            return result;
        } catch (Exception e) {
            instance.finish_transfer=true;
            return "Exception: " + e.getMessage();
        }
    }

    @Override
    protected void onPostExecute(String result){
        Context toastcontext = context.getApplicationContext();
        String text;

        if(result.toLowerCase().contains("successful"))//loggedin is set back to false by then
            text=context.getString(R.string.submit_success);
        else
            text="SERVER: "+result;

        Toast toast = Toast.makeText(toastcontext, text, MainActivity.DURATION);
        toast.show();
    }
}