package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by tianmi on 17.10.15.
 */
public class SignupActivity  extends AsyncTask<String,Void,String> {
    private Context context;
    private Login instance;

    public SignupActivity(Activity act, Context context) {
        instance=(Login)act;
        this.context=context;
    }

    protected void onPreExecute() {

    }

    @Override
    protected String doInBackground(String... arg0) {
        //post method
        try {
            String username = (String) arg0[0];
            String password = (String) arg0[1];

            String link = MainActivity.Domain+"signuppost_tuse.php";
            String data = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");

            URL url = new URL(link);
            HttpsURLConnection conn =(HttpsURLConnection) url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            String result=sb.toString();
            if(result.toLowerCase().contains("successful"))
            {
                instance.set_loggedin(true);
            }
            instance.set_triedtologin(true);
            return result;
        } catch (Exception e) {
            instance.set_triedtologin(true);
            return "Exception: " + e.getMessage();
        }
    }

    @Override
    protected void onPostExecute(String result){
        Context toastcontext = context.getApplicationContext();
        String text;

        if(result.toLowerCase().contains("successful"))//loggedin is set back to false by then
            text=context.getString(R.string.signup_success);
        else
            text="SERVER: "+result;

        Toast toast = Toast.makeText(toastcontext, text, MainActivity.DURATION);
        toast.show();
    }
}