package com.example.tianmi.tuse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Movie;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Picasso;

import java.io.IOException;


public class DisplayMine extends AppCompatActivity {

    private String data;

    private ImageView image_View;
    private int width = MainActivity.QRsize;
    private int height = MainActivity.QRsize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_mine);

        //get data to be qrcoded
        //but really, using bundle to get others, ergo display others as well!!
        SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        data=sharedpreferences.getString(MainActivity.Name, " ");
        //generate code image
        image_View = (ImageView) findViewById(R.id.image_view);
        generate();
    }

    protected void generate()
    {
        QRCodeWriter writer = new QRCodeWriter();
        //qrcode
        try {
            BitMatrix bitMatrix =
                    writer.encode(data, BarcodeFormat.QR_CODE, MainActivity.QRsize, MainActivity.QRsize);

            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    if (bitMatrix.get(x, y))
                        bmp.setPixel(x, y, Color.BLACK);
                    else
                        bmp.setPixel(x, y, Color.WHITE);
                }
            }
            image_View.setImageBitmap(bmp);
        } catch (WriterException e) {
            Log.e("QR ERROR", "" + e);
            Toast toast=Toast.makeText(this.getApplicationContext(), "QR ERROR. " + this.getString(R.string.return_try), MainActivity.DURATION);
            toast.show();
        }
    }
}