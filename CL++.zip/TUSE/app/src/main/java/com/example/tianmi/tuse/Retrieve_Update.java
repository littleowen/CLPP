package com.example.tianmi.tuse;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by tianmi on 17.10.15.
 */
//upload filesystem
//    and download existing own and other cards
public class Retrieve_Update extends AsyncTask<String,Void,String> {

    private MainActivity instance;
    private String fs;//"" means not logged in
    private String username;//"" means not logged in
    private boolean loggedin;

    private String owncard;
    private Set<String> othercard;

    public Retrieve_Update (Activity activity, String name, String filesystem, boolean loggedin) {
        instance=(MainActivity) activity;
        username=name;
        fs=filesystem;
        this.loggedin=loggedin;
    }

    @Override
    protected String doInBackground(String... arg0) {
        if(!loggedin) {//if not logged in no need to update
            try{ Thread.sleep(60000); }catch(InterruptedException e){
            }
            return "";
        }

        //post method
        try {
            String link = MainActivity.Domain+"update_tuse.php";
            String data = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(fs, "UTF-8");

            URL url = new URL(link);
            HttpsURLConnection conn =(HttpsURLConnection) url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line+"\n");//not just one line
            }
            String result=sb.toString();
            if(result.toLowerCase().contains("successful"))
            {
                cards(result.substring(10));//no "successful"
                //now owncard and othercard are set
                instance.set_stuff(owncard, othercard);
            }
        } catch (Exception e) {/*nothing*/        }

        try{ Thread.sleep(60000); }catch(InterruptedException e){
        }
        return "";
    }

    private void cards (String temp){//seperate own and othercard
        //not just one line
        //doesn't matter if still \n after othercard
        String card;
        //make temp end with " "
        temp=temp.substring(0, temp.lastIndexOf(" ")+1);
        //count occurence if '\n'==number of owncards in the set
        int counter = 0;
        for( int i=0; i<temp.length(); i++ ) {
            if( temp.charAt(i) == '\n' ) {
                counter++;
            }
        }

        othercard = new HashSet<String>();
        owncard=temp.substring(0, temp.indexOf('\n'));
        temp=temp.substring(temp.indexOf('\n')+1);

        for(int j=0; j<counter; j++) {
            card=temp.substring(0, temp.indexOf('\n'));
            temp=temp.substring(temp.indexOf('\n')+1);
            othercard.add(card);
        }
    }

    @Override
    protected void onPostExecute(String result) {
        //new async
        instance.async();
    }
}
